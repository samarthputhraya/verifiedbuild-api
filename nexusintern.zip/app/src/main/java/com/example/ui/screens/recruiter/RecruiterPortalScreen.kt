package com.example.ui.screens.recruiter

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AssessmentReportEntity
import com.example.data.model.HackathonEntity
import com.example.data.model.InternshipRequirementEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.RecruiterEntity
import com.example.data.model.SharedCandidateEntity
import com.example.data.model.StudentEntity
import com.example.ui.components.InteractiveRadarChart
import com.example.ui.components.ScoreBadge
import com.example.ui.components.SkillChip
import com.example.ui.components.StatusBadge

@Composable
fun RecruiterPortalScreen(
    currentRecruiter: RecruiterEntity,
    sharedCandidates: List<SharedCandidateEntity>,
    students: List<StudentEntity>,
    projects: List<ProjectEntity>,
    reports: List<AssessmentReportEntity>,
    hackathons: List<HackathonEntity>,
    requirements: List<InternshipRequirementEntity>,
    onPostRequirement: (role: String, skills: String, domains: String, criteria: String, duration: String, location: String, stipend: String, deadline: String) -> Unit,
    onEstablishPassword: (String) -> Unit,
    onContactCandidate: (studentId: String, message: String) -> Unit,
    onSwitchRole: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Shared Candidates (${sharedCandidates.size})", "Internship Openings (${requirements.size})")

    var inspectingCandidate by remember { mutableStateOf<SharedCandidateEntity?>(null) }
    var showPostRequirementDialog by remember { mutableStateOf(false) }
    var showContactDialog by remember { mutableStateOf<StudentEntity?>(null) }
    var showSetPasswordDialog by remember { mutableStateOf(!currentRecruiter.permanentPasswordEstablished) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFBFBF9))
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("recruiter_portal_screen")
    ) {
        // App Bar
        Surface(
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE5E2DA))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = Color(0xFFFEF3C7),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "RECRUITER PORTAL",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF92400E),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    Text(
                        text = "${currentRecruiter.companyName} • ${currentRecruiter.fullName}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF18181B),
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!currentRecruiter.permanentPasswordEstablished) {
                        Button(
                            onClick = { showSetPasswordDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB45309)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Set Password")
                        }
                    }

                    IconButton(onClick = onSwitchRole, modifier = Modifier.testTag("recruiter_switch_role_button")) {
                        Icon(Icons.Default.SwitchAccount, contentDescription = "Switch Role", tint = Color(0xFF18181B))
                    }
                }
            }
        }

        // Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            contentColor = Color(0xFF18181B),
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = Color(0xFFB45309),
                    height = 2.5.dp
                )
            }
        ) {
            tabs.forEachIndexed { idx, title ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = { selectedTab = idx },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTab == idx) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (selectedTab == idx) Color(0xFF18181B) else Color(0xFF64748B)
                        )
                    }
                )
            }
        }

        // Tab Content
        when (selectedTab) {
            0 -> {
                // Shared Candidates
                if (inspectingCandidate != null) {
                    val shared = inspectingCandidate!!
                    val candidate = students.find { it.id == shared.studentId }
                    val project = projects.find { it.id == shared.projectId }
                    val report = reports.find { it.projectId == shared.projectId }
                    val candidateHackathons = hackathons.filter { it.studentId == shared.studentId }

                    if (candidate != null && project != null) {
                        RecruiterCandidateDetailView(
                            candidate = candidate,
                            project = project,
                            report = report,
                            hackathons = candidateHackathons,
                            shared = shared,
                            onBack = { inspectingCandidate = null },
                            onContact = { showContactDialog = candidate }
                        )
                    } else {
                        inspectingCandidate = null
                    }
                } else {
                    SharedCandidatesListView(
                        sharedCandidates = sharedCandidates,
                        students = students,
                        projects = projects,
                        reports = reports,
                        requirements = requirements,
                        onInspect = { inspectingCandidate = it }
                    )
                }
            }

            1 -> {
                // Requirements
                InternshipRequirementsListView(
                    requirements = requirements,
                    onPostRequirementClick = { showPostRequirementDialog = true }
                )
            }
        }
    }

    // Set Permanent Password Dialog
    if (showSetPasswordDialog) {
        var newPass by remember { mutableStateOf("") }
        var confirmPass by remember { mutableStateOf("") }
        var errorMsg by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { if (currentRecruiter.permanentPasswordEstablished) showSetPasswordDialog = false },
            containerColor = Color.White,
            title = {
                Text(
                    text = "Establish Permanent Password",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF18181B)
                )
            },
            text = {
                Column {
                    Text(
                        text = "Your account was provisioned with temporary access. Establish your confidential permanent password to secure company evaluations.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF475569),
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    OutlinedTextField(
                        value = newPass,
                        onValueChange = { newPass = it },
                        label = { Text("New Permanent Password") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("new_password_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = confirmPass,
                        onValueChange = { confirmPass = it },
                        label = { Text("Confirm Password") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("confirm_password_input")
                    )

                    if (errorMsg != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = errorMsg ?: "", style = MaterialTheme.typography.bodySmall, color = Color(0xFFDC2626))
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPass.length < 6) {
                            errorMsg = "Password must be at least 6 characters."
                            return@Button
                        }
                        if (newPass != confirmPass) {
                            errorMsg = "Passwords do not match."
                            return@Button
                        }
                        onEstablishPassword(newPass)
                        showSetPasswordDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("confirm_set_password_button")
                ) {
                    Text("Save & Activate")
                }
            },
            dismissButton = {
                if (currentRecruiter.permanentPasswordEstablished) {
                    OutlinedButton(
                        onClick = { showSetPasswordDialog = false },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Cancel")
                    }
                }
            }
        )
    }

    // Contact Candidate Dialog
    if (showContactDialog != null) {
        val cand = showContactDialog!!
        var outreachMsg by remember {
            mutableStateOf("Hi ${cand.fullName}, we were impressed by your verified repository assessment and would like to invite you for a 30-minute technical discussion.")
        }
        var sentOutreach by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showContactDialog = null },
            containerColor = Color.White,
            title = {
                Text(
                    text = "Permitted Candidate Outreach",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF18181B)
                )
            },
            text = {
                Column {
                    Text(
                        text = "Send direct corporate internship outreach to ${cand.fullName} (${cand.email}).",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF475569)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = outreachMsg,
                        onValueChange = { outreachMsg = it },
                        label = { Text("Invitation Message") },
                        minLines = 4,
                        modifier = Modifier.fillMaxWidth().testTag("outreach_message_input")
                    )

                    if (sentOutreach) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(color = Color(0xFFD1FAE5), shape = RoundedCornerShape(6.dp)) {
                            Text(
                                text = "Outreach message delivered to candidate inbox!",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF065F46),
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onContactCandidate(cand.id, outreachMsg)
                        sentOutreach = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("send_outreach_btn")
                ) {
                    Text("Send Invitation")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showContactDialog = null }, shape = RoundedCornerShape(8.dp)) {
                    Text("Close")
                }
            }
        )
    }

    // Post Requirement Dialog
    if (showPostRequirementDialog) {
        var roleTitle by remember { mutableStateOf("") }
        var reqSkills by remember { mutableStateOf("") }
        var prefDomains by remember { mutableStateOf("") }
        var criteria by remember { mutableStateOf("CGPA >= 8.5, 3rd/4th Year B.Tech") }
        var duration by remember { mutableStateOf("6 Months") }
        var location by remember { mutableStateOf("Bengaluru (Hybrid)") }
        var stipend by remember { mutableStateOf("₹1,00,000 / month") }
        var deadline by remember { mutableStateOf("November 30, 2026") }

        AlertDialog(
            onDismissRequest = { showPostRequirementDialog = false },
            containerColor = Color.White,
            title = {
                Text(
                    text = "Post New Internship Requirement",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF18181B)
                )
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(
                        value = roleTitle,
                        onValueChange = { roleTitle = it },
                        label = { Text("Role Title") },
                        placeholder = { Text("e.g. Distributed Systems Intern") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("req_role_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = reqSkills,
                        onValueChange = { reqSkills = it },
                        label = { Text("Required Skills (comma separated)") },
                        placeholder = { Text("Go, Kotlin, gRPC, Docker") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("req_skills_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = prefDomains,
                        onValueChange = { prefDomains = it },
                        label = { Text("Preferred Domains") },
                        placeholder = { Text("Cloud Backend, Systems") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("req_domains_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = criteria,
                        onValueChange = { criteria = it },
                        label = { Text("Eligibility Criteria") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("req_criteria_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = duration,
                            onValueChange = { duration = it },
                            label = { Text("Duration") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = stipend,
                            onValueChange = { stipend = it },
                            label = { Text("Stipend") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = deadline,
                        onValueChange = { deadline = it },
                        label = { Text("Application Deadline") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (roleTitle.isNotBlank() && reqSkills.isNotBlank()) {
                            onPostRequirement(
                                roleTitle,
                                reqSkills,
                                prefDomains,
                                criteria,
                                duration,
                                location,
                                stipend,
                                deadline
                            )
                            showPostRequirementDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("confirm_post_req_button")
                ) {
                    Text("Post Requirement")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showPostRequirementDialog = false }, shape = RoundedCornerShape(8.dp)) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun SharedCandidatesListView(
    sharedCandidates: List<SharedCandidateEntity>,
    students: List<StudentEntity>,
    projects: List<ProjectEntity>,
    reports: List<AssessmentReportEntity>,
    requirements: List<InternshipRequirementEntity>,
    onInspect: (SharedCandidateEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Surface(
                color = Color(0xFFF4F3EE),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF475569), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Authorized Access Only: Recruiters inspect only candidates explicitly shared by Administrators. Raw interview answers and private integrity logs remain confidential.",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF475569),
                        lineHeight = 16.sp
                    )
                }
            }
        }

        if (sharedCandidates.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        text = "No candidates forwarded by Admin yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF64748B)
                    )
                }
            }
        } else {
            items(sharedCandidates) { shared ->
                val student = students.find { it.id == shared.studentId }
                val project = projects.find { it.id == shared.projectId }
                val report = reports.find { it.projectId == shared.projectId }

                if (student != null && project != null) {
                    // Match Justification
                    val primaryReq = requirements.firstOrNull()
                    val matchReason = "AI Match Justification: Candidate demonstrates verified proficiency in ${student.technicalSkills.split(",").take(3).joinToString(", ")}, validated through '${project.title}' (Score: ${report?.overallScore ?: 90}/100)."

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onInspect(shared) }
                            .testTag("recruiter_candidate_card_${student.id}"),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = student.fullName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF18181B)
                                    )
                                    Text(
                                        text = "${student.college} • CGPA ${student.cgpa}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF64748B)
                                    )
                                }

                                if (report != null) {
                                    ScoreBadge(score = report.overallScore)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // AI Match Rationale Box
                            Surface(
                                color = Color(0xFFF0FDF4),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Icon(
                                        Icons.Default.Psychology,
                                        contentDescription = null,
                                        tint = Color(0xFF166534),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = matchReason,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF14532D),
                                        lineHeight = 18.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "Forwarded Project: ${project.title}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF1E293B)
                            )
                            Text(
                                text = "Admin Note: ${shared.adminNotes}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF475569)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                StatusBadge(status = shared.recruiterStatus)

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "View Authorized Dossier",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF0F766E)
                                    )
                                    Icon(
                                        Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = null,
                                        tint = Color(0xFF0F766E),
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecruiterCandidateDetailView(
    candidate: StudentEntity,
    project: ProjectEntity,
    report: AssessmentReportEntity?,
    hackathons: List<HackathonEntity>,
    shared: SharedCandidateEntity,
    onBack: () -> Unit,
    onContact: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Authorized Candidate Profile",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF18181B)
                    )
                    Text(
                        text = "${candidate.fullName} • ${candidate.college}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF64748B)
                    )
                }

                Button(
                    onClick = onContact,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("recruiter_outreach_button")
                ) {
                    Icon(Icons.Default.Email, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Outreach")
                }
            }
        }

        // Academic Details & Verified Hackathons
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Academic Credentials & Hackathons", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "CGPA: ${candidate.cgpa} • Major: ${candidate.branch}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF334155))
                    Text(text = "Technical Stack: ${candidate.technicalSkills}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF475569))

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(text = "Verified Hackathons:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    hackathons.forEach { h ->
                        Text(
                            text = "• ${h.eventName} (${h.rankOrPerformance}, ${h.year})",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF0F766E)
                        )
                    }
                }
            }
        }

        // Approved Performance Report & Radar Chart
        if (report != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Admin-Approved Technical Assessment",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF18181B)
                            )
                            ScoreBadge(score = report.overallScore)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Evaluated on repository: ${project.title}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Interactive Radar Chart
                        InteractiveRadarChart(report = report)

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(text = "Demonstrated Strengths:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        Text(text = report.strengths, style = MaterialTheme.typography.bodySmall, color = Color(0xFF334155))
                    }
                }
            }
        }
    }
}

@Composable
private fun InternshipRequirementsListView(
    requirements: List<InternshipRequirementEntity>,
    onPostRequirementClick: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Active Internship Openings",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF18181B)
                    )
                    Text(
                        text = "Define criteria for AI matching and shortlist recommendations",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF64748B)
                    )
                }

                Button(
                    onClick = onPostRequirementClick,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("post_internship_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Post Opening")
                }
            }
        }

        items(requirements) { req ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = req.roleTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF18181B)
                            )
                            Text(
                                text = "${req.companyName} • ${req.location}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF0F766E),
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Surface(
                            color = Color(0xFFD1FAE5),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = req.stipend,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF065F46),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Required Stack: ${req.requiredSkills}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF334155)
                    )
                    Text(
                        text = "Eligibility: ${req.eligibilityCriteria} • Duration: ${req.duration}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF64748B)
                    )
                    Text(
                        text = "Application Deadline: ${req.deadline}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFFB45309),
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}
