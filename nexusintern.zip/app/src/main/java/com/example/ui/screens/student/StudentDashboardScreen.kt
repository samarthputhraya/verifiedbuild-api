package com.example.ui.screens.student

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConnectionEntity
import com.example.data.model.HackathonEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.StudentEntity
import com.example.ui.components.SkillChip
import com.example.ui.components.StatusBadge

@Composable
fun StudentDashboardScreen(
    student: StudentEntity,
    projects: List<ProjectEntity>,
    hackathons: List<HackathonEntity>,
    connections: List<ConnectionEntity>,
    allStudents: List<StudentEntity>,
    notifications: List<NotificationEntity>,
    onOpenProject: (String) -> Unit,
    onEditProfile: () -> Unit,
    onSubmitNewProject: (title: String, repoUrl: String, onComplete: (Result<ProjectEntity>) -> Unit) -> Unit,
    onAcceptConnection: (String) -> Unit,
    onSendConnection: (String) -> Unit,
    onSwitchRole: () -> Unit
) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showAddProjectDialog by remember { mutableStateOf(false) }

    val tabs = listOf("Projects & Evaluations", "Technical Portfolio", "Mutual Connections", "Notifications (${notifications.size})")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFBFBF9))
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("student_dashboard_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header: Student Identity & Role Switch
            Surface(
                color = Color.White,
                border = BorderStroke(1.dp, Color(0xFFE5E2DA))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFFF4F3EE),
                                border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                                modifier = Modifier.size(46.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = student.fullName.take(1).uppercase(),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF1E293B)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = student.fullName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF18181B)
                                    )
                                    if (student.isEmailVerified) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            Icons.Default.Verified,
                                            contentDescription = "Verified Identity",
                                            tint = Color(0xFF0F766E),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "${student.college} • CGPA ${student.cgpa}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }

                        // Actions
                        Row {
                            IconButton(
                                onClick = onEditProfile,
                                modifier = Modifier.testTag("edit_profile_button")
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = Color(0xFF475569))
                            }
                            IconButton(
                                onClick = onSwitchRole,
                                modifier = Modifier.testTag("switch_role_button")
                            ) {
                                Icon(Icons.Default.SwitchAccount, contentDescription = "Switch Role", tint = Color(0xFF1E293B))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Bio / Focus statement
                    if (student.bio.isNotBlank()) {
                        Text(
                            text = student.bio,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF475569),
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            // Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = Color.White,
                contentColor = Color(0xFF18181B),
                edgePadding = 16.dp,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = Color(0xFF0F766E),
                        height = 2.5.dp
                    )
                }
            ) {
                tabs.forEachIndexed { index, tabTitle ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = tabTitle,
                                fontWeight = if (selectedTabIndex == index) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (selectedTabIndex == index) Color(0xFF18181B) else Color(0xFF64748B)
                            )
                        }
                    )
                }
            }

            // Tab Content
            when (selectedTabIndex) {
                0 -> {
                    // TAB 0: Projects & AI Assessment Status
                    ProjectsTabContent(
                        projects = projects,
                        onOpenProject = onOpenProject,
                        onAddProjectClick = { showAddProjectDialog = true }
                    )
                }
                1 -> {
                    // TAB 1: Technical Portfolio Details
                    PortfolioTabContent(student = student, hackathons = hackathons)
                }
                2 -> {
                    // TAB 2: Mutual Connections System
                    ConnectionsTabContent(
                        currentStudentId = student.id,
                        connections = connections,
                        allStudents = allStudents,
                        onAccept = onAcceptConnection,
                        onSend = onSendConnection
                    )
                }
                3 -> {
                    // TAB 3: Notifications
                    NotificationsTabContent(notifications = notifications)
                }
            }
        }

        // Floating Action Button to Add Project
        if (selectedTabIndex == 0) {
            FloatingActionButton(
                onClick = { showAddProjectDialog = true },
                containerColor = Color(0xFF1E293B),
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(20.dp)
                    .testTag("add_project_fab")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Project")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Project", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }

    // Add Project Dialog
    if (showAddProjectDialog) {
        AddProjectDialog(
            onDismiss = { showAddProjectDialog = false },
            onSubmit = { title, repoUrl, onResult ->
                onSubmitNewProject(title, repoUrl) { result ->
                    onResult(result)
                    if (result.isSuccess) {
                        showAddProjectDialog = false
                    }
                }
            }
        )
    }
}

@Composable
private fun ProjectsTabContent(
    projects: List<ProjectEntity>,
    onOpenProject: (String) -> Unit,
    onAddProjectClick: () -> Unit
) {
    if (projects.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Default.Code,
                    contentDescription = null,
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(54.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "No Repository Projects Submitted Yet",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF18181B)
                )
                Text(
                    text = "Submit a public GitHub repository to initiate project-specific AI technical interviews and rubric assessments.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF64748B),
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                Button(
                    onClick = onAddProjectClick,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("empty_add_project_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Project")
                }
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Surface(
                    color = Color(0xFFF4F3EE),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color(0xFFE5E2DA))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF475569), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Auditable Submissions: Submitted projects and completed assessments cannot be deleted directly to preserve academic evaluation integrity.",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF475569),
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            items(projects, key = { it.id }) { proj ->
                ProjectSubmissionCard(
                    project = proj,
                    onClick = { onOpenProject(proj.id) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(64.dp))
            }
        }
    }
}

@Composable
private fun ProjectSubmissionCard(
    project: ProjectEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("project_card_${project.id}")
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE5E2DA))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = project.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF18181B)
                    )
                    Text(
                        text = project.githubRepoUrl,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF0284C7)
                    )
                }

                StatusBadge(status = project.status)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = project.repoDescription,
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF475569),
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Tech stats row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = project.languages,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF64748B)
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Open Details",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF0F766E)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = Color(0xFF0F766E),
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PortfolioTabContent(
    student: StudentEntity,
    hackathons: List<HackathonEntity>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Academic Details Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Academic Credentials",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF18181B)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "College: ${student.college}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF334155))
                    Text(text = "Department: ${student.branch}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF475569))
                    Text(text = "Year: ${student.academicYear} • CGPA: ${student.cgpa}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF475569))
                }
            }
        }

        // Skills & Domains Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Technical Skills & Competencies",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF18181B)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        student.technicalSkills.split(",").take(6).forEach {
                            SkillChip(skill = it)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Target Internship Domains",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64748B)
                    )
                    Text(
                        text = student.preferredDomains,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF334155)
                    )
                }
            }
        }

        // Hackathon Achievements
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = Color(0xFFB45309), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Hackathon Achievements & Awards",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF18181B)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (hackathons.isEmpty()) {
                        Text("No hackathons recorded yet.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B))
                    } else {
                        hackathons.forEach { hack ->
                            Column(modifier = Modifier.padding(bottom = 10.dp)) {
                                Text(
                                    text = hack.eventName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF18181B)
                                )
                                Text(
                                    text = "${hack.rankOrPerformance} • Year ${hack.year}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF0F766E)
                                )
                                Text(
                                    text = "Certificate: ${hack.certificateTitle}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ConnectionsTabContent(
    currentStudentId: String,
    connections: List<ConnectionEntity>,
    allStudents: List<StudentEntity>,
    onAccept: (String) -> Unit,
    onSend: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Surface(
                color = Color(0xFFF4F3EE),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF475569), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Mutual Privacy Guarantee: Mutual connections can collaborate and view public profiles, but NEVER gain access to private resumes, internal AI assessment reports, or raw interview transcripts.",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF475569),
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Active / Pending Connections
        item {
            Text(
                text = "Connection Requests & Mutuals",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF18181B)
            )
        }

        if (connections.isEmpty()) {
            item {
                Text(
                    text = "No connection requests yet.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF64748B)
                )
            }
        } else {
            items(connections) { conn ->
                val otherId = if (conn.requesterStudentId == currentStudentId) conn.targetStudentId else conn.requesterStudentId
                val otherStudent = allStudents.find { it.id == otherId }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = otherStudent?.fullName ?: "Student Candidate",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF18181B)
                            )
                            Text(
                                text = "${otherStudent?.college ?: "University"} • ${otherStudent?.branch ?: ""}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF64748B)
                            )
                        }

                        if (conn.status == "PENDING" && conn.targetStudentId == currentStudentId) {
                            Button(
                                onClick = { onAccept(conn.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("Accept")
                            }
                        } else {
                            StatusBadge(status = conn.status)
                        }
                    }
                }
            }
        }

        // Discover Peers
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Discover Engineering Peers",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF18181B)
            )
        }

        val peers = allStudents.filter { it.id != currentStudentId && connections.none { c -> c.requesterStudentId == it.id || c.targetStudentId == it.id } }
        if (peers.isEmpty()) {
            item {
                Text(text = "All peers connected.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B))
            }
        } else {
            items(peers) { peer ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = peer.fullName,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF18181B)
                            )
                            Text(
                                text = "${peer.college} • ${peer.branch}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF64748B)
                            )
                        }

                        OutlinedButton(
                            onClick = { onSend(peer.id) },
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Connect")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationsTabContent(notifications: List<NotificationEntity>) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (notifications.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No notifications yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF64748B)
                    )
                }
            }
        } else {
            items(notifications) { notif ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            Icons.Default.Notifications,
                            contentDescription = null,
                            tint = Color(0xFF0F766E),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = notif.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF18181B)
                            )
                            Text(
                                text = notif.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF475569),
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddProjectDialog(
    onDismiss: () -> Unit,
    onSubmit: (title: String, repoUrl: String, onResult: (Result<ProjectEntity>) -> Unit) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var repoUrl by remember { mutableStateOf("https://github.com/") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = { if (!isLoading) onDismiss() },
        containerColor = Color.White,
        title = {
            Text(
                text = "Add GitHub Repository Project",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF18181B)
            )
        },
        text = {
            Column {
                Text(
                    text = "Submit an accessible public repository for architectural analysis and repository-specific AI technical assessment.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF64748B),
                    modifier = Modifier.padding(bottom = 14.dp)
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        errorMessage = null
                    },
                    label = { Text("Project Title") },
                    placeholder = { Text("e.g. Distributed Key-Value Store") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_project_title_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = repoUrl,
                    onValueChange = {
                        repoUrl = it
                        errorMessage = null
                    },
                    label = { Text("GitHub Repository URL") },
                    placeholder = { Text("https://github.com/owner/repository") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_project_url_input")
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = Color(0xFFFFE4E6),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFBE123C),
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                if (isLoading) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color(0xFF0F766E))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Auditing repository via GitHub API...", style = MaterialTheme.typography.bodySmall, color = Color(0xFF475569))
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank() || repoUrl.isBlank()) {
                        errorMessage = "Please enter both project title and GitHub URL."
                        return@Button
                    }
                    isLoading = true
                    errorMessage = null
                    onSubmit(title, repoUrl) { result ->
                        isLoading = false
                        result.onFailure {
                            errorMessage = it.message ?: "Failed to validate repository."
                        }
                    }
                },
                enabled = !isLoading,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("submit_project_confirm_button")
            ) {
                Text("Analyze & Submit")
            }
        },
        dismissButton = {
            if (!isLoading) {
                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Cancel")
                }
            }
        }
    )
}
