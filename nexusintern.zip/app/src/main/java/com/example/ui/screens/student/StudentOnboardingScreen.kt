package com.example.ui.screens.student

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.HackathonEntity
import com.example.data.model.StudentEntity
import com.example.network.GeminiAiService
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun StudentOnboardingScreen(
    initialStudent: StudentEntity?,
    onSaveProfile: (StudentEntity, List<HackathonEntity>) -> Unit,
    onCancel: () -> Unit
) {
    var step by remember { mutableIntStateOf(1) }
    val scope = rememberCoroutineScope()

    // Form State
    var fullName by remember { mutableStateOf(initialStudent?.fullName ?: "") }
    var email by remember { mutableStateOf(initialStudent?.email ?: "") }
    var verificationCode by remember { mutableStateOf("") }
    var isEmailVerified by remember { mutableStateOf(initialStudent?.isEmailVerified ?: false) }
    var verificationSent by remember { mutableStateOf(false) }

    // Resume Extracted Fields (Editable bullet points)
    var resumeRawText by remember {
        mutableStateOf(
            """
            Aarav Deshmukh
            Email: aarav.deshmukh@vit.ac.in
            College: Vellore Institute of Technology
            Branch: Computer Science and Engineering
            Academic Year: 3rd Year (Class of 2026)
            CGPA: 9.18
            Technical Skills: Kotlin, Jetpack Compose, Coroutines, Room, Go, gRPC, Docker, PostgreSQL, Redis
            Experience: Software Engineering Intern at CloudMatrix (Summer 2025)
            Projects: Chronos: Distributed Log Engine; Raft Consensus KV Store
            """.trimIndent()
        )
    }
    var isExtractingResume by remember { mutableStateOf(false) }

    var college by remember { mutableStateOf(initialStudent?.college ?: "Vellore Institute of Technology") }
    var branch by remember { mutableStateOf(initialStudent?.branch ?: "Computer Science and Engineering") }
    var academicYear by remember { mutableStateOf(initialStudent?.academicYear ?: "3rd Year (Class of 2026)") }
    var cgpaText by remember { mutableStateOf(initialStudent?.cgpa?.toString() ?: "9.18") }
    var technicalSkills by remember { mutableStateOf(initialStudent?.technicalSkills ?: "Kotlin, Jetpack Compose, Coroutines, Room, Go, gRPC") }
    var experienceSummary by remember { mutableStateOf(initialStudent?.experienceSummary ?: "Software Engineering Intern at CloudMatrix (Summer 2025)") }
    var resumeProjects by remember { mutableStateOf(initialStudent?.resumeSummary ?: "Chronos: Distributed Log Engine in Go; Raft Consensus KV Store") }

    // GitHub
    var githubProfileUrl by remember { mutableStateOf(initialStudent?.githubProfileUrl ?: "https://github.com/aarav-deshmukh") }

    // Areas of Interest & Preferred Domains
    var areasOfInterest by remember { mutableStateOf(initialStudent?.areasOfInterest ?: "Distributed Systems, Mobile Performance Architecture, Real-Time Systems") }
    var preferredDomains by remember { mutableStateOf(initialStudent?.preferredDomains ?: "Systems Engineering, Core Android, Cloud Infrastructure") }
    var bio by remember { mutableStateOf(initialStudent?.bio ?: "Systems-oriented Android & Backend engineer interested in zero-allocation data structures.") }

    // Hackathons (Multiple entries allowed)
    val hackathons = remember {
        mutableStateListOf(
            HackathonEntity(
                id = "hack_init_1",
                studentId = initialStudent?.id ?: "student_default",
                eventName = "Smart India Hackathon 2025",
                rankOrPerformance = "1st Place Winner (National)",
                year = "2025",
                certificateTitle = "Ministry of Education Gold Citation"
            )
        )
    }

    var newHackEvent by remember { mutableStateOf("") }
    var newHackRank by remember { mutableStateOf("") }
    var newHackYear by remember { mutableStateOf("") }
    var newHackCert by remember { mutableStateOf("") }

    val totalSteps = 6

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFBFBF9))
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("student_onboarding_screen")
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    if (step > 1) step-- else onCancel()
                },
                modifier = Modifier.testTag("onboarding_back_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color(0xFF18181B))
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Student Registration",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF18181B)
                )
                Text(
                    text = "Step $step of $totalSteps",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF64748B)
                )
            }
        }

        LinearProgressIndicator(
            progress = { step.toFloat() / totalSteps },
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp),
            color = Color(0xFF0F766E),
            trackColor = Color(0xFFE5E2DA)
        )

        // Main Scrollable Form Area
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 20.dp)
        ) {
            when (step) {
                1 -> {
                    // STEP 1: Name and Email Verification
                    Text(
                        text = "Identity & Email Verification",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF18181B)
                    )
                    Text(
                        text = "Enter your full name and official academic email address to begin your verified portfolio.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF475569),
                        modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
                    )

                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Full Name") },
                        placeholder = { Text("e.g. Aarav Deshmukh") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("full_name_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF1E293B),
                            unfocusedBorderColor = Color(0xFFD6D3CD)
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = email,
                        onValueChange = {
                            email = it
                            isEmailVerified = false
                        },
                        label = { Text("Academic or Professional Email") },
                        placeholder = { Text("aarav.deshmukh@vit.ac.in") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("email_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF1E293B),
                            unfocusedBorderColor = Color(0xFFD6D3CD)
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    if (!isEmailVerified) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "Email Verification",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF18181B)
                                )
                                Text(
                                    text = "A 6-digit confirmation code will be dispatched to confirm your identity.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF64748B),
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )

                                if (verificationSent) {
                                    OutlinedTextField(
                                        value = verificationCode,
                                        onValueChange = { verificationCode = it },
                                        label = { Text("Verification Code (Enter 749210)") },
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 8.dp)
                                            .testTag("verification_code_input")
                                    )

                                    Button(
                                        onClick = {
                                            if (verificationCode.isNotBlank()) {
                                                isEmailVerified = true
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.testTag("confirm_verify_button")
                                    ) {
                                        Text("Verify Email Address")
                                    }
                                } else {
                                    Button(
                                        onClick = {
                                            verificationSent = true
                                            verificationCode = "749210"
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.testTag("send_verify_code_button")
                                    ) {
                                        Text("Send Verification Code")
                                    }
                                }
                            }
                        }
                    } else {
                        Surface(
                            color = Color(0xFFD1FAE5),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF065F46))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Email address verified successfully",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF065F46)
                                )
                            }
                        }
                    }
                }

                2 -> {
                    // STEP 2: Upload Resume & Editable Extracted Bullet Points
                    Text(
                        text = "Resume Analysis & Parsing",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF18181B)
                    )
                    Text(
                        text = "Upload or paste your technical resume. Information is extracted into editable bullet points below. Missing items are never invented.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF475569),
                        modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                    )

                    OutlinedTextField(
                        value = resumeRawText,
                        onValueChange = { resumeRawText = it },
                        label = { Text("Resume Content / Text") },
                        minLines = 5,
                        maxLines = 8,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("resume_text_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                scope.launch {
                                    isExtractingResume = true
                                    val data = GeminiAiService.extractResume(resumeRawText)
                                    if (data.fullName.isNotBlank()) fullName = data.fullName
                                    if (data.email.isNotBlank()) email = data.email
                                    if (data.college.isNotBlank()) college = data.college
                                    if (data.branch.isNotBlank()) branch = data.branch
                                    if (data.academicYear.isNotBlank()) academicYear = data.academicYear
                                    if (data.cgpa > 0.0) cgpaText = data.cgpa.toString()
                                    if (data.skills.isNotBlank()) technicalSkills = data.skills
                                    if (data.experience.isNotBlank()) experienceSummary = data.experience
                                    if (data.projects.isNotBlank()) resumeProjects = data.projects
                                    isExtractingResume = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                            shape = RoundedCornerShape(8.dp),
                            enabled = !isExtractingResume,
                            modifier = Modifier.testTag("extract_resume_button")
                        ) {
                            if (isExtractingResume) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Analyzing...")
                            } else {
                                Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Extract Resume Fields")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "Editable Extracted Information:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF18181B)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = college,
                        onValueChange = { college = it },
                        label = { Text("College / University") },
                        modifier = Modifier.fillMaxWidth().testTag("college_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = branch,
                            onValueChange = { branch = it },
                            label = { Text("Branch / Major") },
                            modifier = Modifier.weight(1.5f).testTag("branch_input")
                        )
                        OutlinedTextField(
                            value = cgpaText,
                            onValueChange = { cgpaText = it },
                            label = { Text("CGPA") },
                            modifier = Modifier.weight(1f).testTag("cgpa_input")
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = academicYear,
                        onValueChange = { academicYear = it },
                        label = { Text("Academic Year") },
                        modifier = Modifier.fillMaxWidth().testTag("academic_year_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = experienceSummary,
                        onValueChange = { experienceSummary = it },
                        label = { Text("Prior Internships & Experience") },
                        modifier = Modifier.fillMaxWidth().testTag("experience_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = resumeProjects,
                        onValueChange = { resumeProjects = it },
                        label = { Text("Notable Projects Summary") },
                        modifier = Modifier.fillMaxWidth().testTag("projects_summary_input")
                    )
                }

                3 -> {
                    // STEP 3: GitHub Profile URL
                    Text(
                        text = "GitHub Developer Identity",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF18181B)
                    )
                    Text(
                        text = "Link your public GitHub profile to authenticate your open-source contributions and codebase submissions.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF475569),
                        modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
                    )

                    OutlinedTextField(
                        value = githubProfileUrl,
                        onValueChange = { githubProfileUrl = it },
                        label = { Text("GitHub Profile URL") },
                        placeholder = { Text("https://github.com/username") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("github_profile_url_input")
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Repository Verification Protocol",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF18181B)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "• Only accessible repositories with public commit history can be evaluated.\n• All project code trees, READMEs, and architecture boundaries are audited using live GitHub API inspection.\n• No fabricated or inaccessible repositories will be analyzed.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF64748B),
                                lineHeight = 20.sp
                            )
                        }
                    }
                }

                4 -> {
                    // STEP 4: Technical Skills, Interests, Preferred Domains
                    Text(
                        text = "Technical Competencies & Domains",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF18181B)
                    )
                    Text(
                        text = "Define your core language proficiencies, engineering interests, and target internship specializations.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF475569),
                        modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
                    )

                    OutlinedTextField(
                        value = technicalSkills,
                        onValueChange = { technicalSkills = it },
                        label = { Text("Technical Skills (comma separated)") },
                        placeholder = { Text("Kotlin, Jetpack Compose, Go, Docker, PostgreSQL") },
                        modifier = Modifier.fillMaxWidth().testTag("skills_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = areasOfInterest,
                        onValueChange = { areasOfInterest = it },
                        label = { Text("Areas of Technical Interest") },
                        placeholder = { Text("Distributed Systems, Mobile Architectures, Zero-Copy Buffers") },
                        modifier = Modifier.fillMaxWidth().testTag("interests_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = preferredDomains,
                        onValueChange = { preferredDomains = it },
                        label = { Text("Preferred Internship Domains") },
                        placeholder = { Text("Core Android Engineering, Cloud Infrastructure") },
                        modifier = Modifier.fillMaxWidth().testTag("domains_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = bio,
                        onValueChange = { bio = it },
                        label = { Text("Engineering Bio / Focus Statement") },
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth().testTag("bio_input")
                    )
                }

                5 -> {
                    // STEP 5: Hackathons & Certificates (Multiple Entries)
                    Text(
                        text = "Hackathon Achievements & Certificates",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF18181B)
                    )
                    Text(
                        text = "Add verified hackathon participations, national/global rankings, and certificate references.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF475569),
                        modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
                    )

                    // Current Hackathons List
                    hackathons.forEachIndexed { index, hack ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 10.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = hack.eventName,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF18181B)
                                    )
                                    Text(
                                        text = "${hack.rankOrPerformance} • ${hack.year}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF0F766E),
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = "Certificate: ${hack.certificateTitle}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF64748B)
                                    )
                                }

                                IconButton(onClick = { hackathons.removeAt(index) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFF94A3B8))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Add New Hackathon Form
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F7F4)),
                        border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Add Hackathon Entry",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF18181B)
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = newHackEvent,
                                onValueChange = { newHackEvent = it },
                                label = { Text("Event Name") },
                                placeholder = { Text("e.g. Smart India Hackathon") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("hackathon_event_input")
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = newHackRank,
                                    onValueChange = { newHackRank = it },
                                    label = { Text("Rank / Performance") },
                                    placeholder = { Text("1st Place Winner") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1.5f).testTag("hackathon_rank_input")
                                )
                                OutlinedTextField(
                                    value = newHackYear,
                                    onValueChange = { newHackYear = it },
                                    label = { Text("Year") },
                                    placeholder = { Text("2025") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f).testTag("hackathon_year_input")
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = newHackCert,
                                onValueChange = { newHackCert = it },
                                label = { Text("Certificate Upload / Reference Title") },
                                placeholder = { Text("Ministry of Education Citation #SIH25") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("hackathon_cert_input")
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = {
                                    if (newHackEvent.isNotBlank()) {
                                        hackathons.add(
                                            HackathonEntity(
                                                id = "hack_" + UUID.randomUUID().toString().take(6),
                                                studentId = initialStudent?.id ?: "student_default",
                                                eventName = newHackEvent.trim(),
                                                rankOrPerformance = if (newHackRank.isBlank()) "Participant" else newHackRank.trim(),
                                                year = if (newHackYear.isBlank()) "2025" else newHackYear.trim(),
                                                certificateTitle = if (newHackCert.isBlank()) "Verified Participation" else newHackCert.trim()
                                            )
                                        )
                                        newHackEvent = ""
                                        newHackRank = ""
                                        newHackYear = ""
                                        newHackCert = ""
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("add_hackathon_button")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Add Entry")
                            }
                        }
                    }
                }

                6 -> {
                    // STEP 6: Review & Confirm Profile
                    Text(
                        text = "Review & Finalize Portfolio",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF18181B)
                    )
                    Text(
                        text = "Confirm your engineering portfolio. After confirmation, you can submit projects for AI assessment.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF475569),
                        modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
                    )

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text(
                                text = fullName.ifBlank { "Aarav Deshmukh" },
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF18181B)
                            )
                            Text(
                                text = email.ifBlank { "candidate@example.edu" },
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF0F766E)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "$college • $branch",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF334155)
                            )
                            Text(
                                text = "CGPA: $cgpaText • $academicYear",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF64748B)
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "Technical Stack",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B)
                            )
                            Text(
                                text = technicalSkills,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF475569)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "GitHub Profile",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B)
                            )
                            Text(
                                text = githubProfileUrl,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF0284C7)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "Hackathon Achievements (${hackathons.size})",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B)
                            )
                            hackathons.forEach { h ->
                                Text(
                                    text = "• ${h.eventName} (${h.rankOrPerformance}, ${h.year})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF475569)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bottom Navigation Action Bar
        Surface(
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE5E2DA))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (step > 1) {
                    OutlinedButton(
                        onClick = { step-- },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("onboarding_prev_button")
                    ) {
                        Text("Previous")
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                if (step < totalSteps) {
                    Button(
                        onClick = { step++ },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("onboarding_next_button")
                    ) {
                        Text("Next Step")
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                } else {
                    Button(
                        onClick = {
                            val studentId = initialStudent?.id ?: "student_default"
                            val parsedCgpa = cgpaText.toDoubleOrNull() ?: 8.5
                            val updatedStudent = StudentEntity(
                                id = studentId,
                                fullName = fullName.ifBlank { "Candidate" },
                                email = email.ifBlank { "candidate@example.edu" },
                                isEmailVerified = isEmailVerified,
                                college = college,
                                branch = branch,
                                academicYear = academicYear,
                                cgpa = parsedCgpa,
                                technicalSkills = technicalSkills,
                                areasOfInterest = areasOfInterest,
                                preferredDomains = preferredDomains,
                                githubProfileUrl = githubProfileUrl,
                                resumeSummary = resumeProjects,
                                experienceSummary = experienceSummary,
                                bio = bio,
                                isOnboardingComplete = true,
                                updatedAt = System.currentTimeMillis()
                            )
                            onSaveProfile(updatedStudent, hackathons)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("confirm_profile_button")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Confirm Profile")
                    }
                }
            }
        }
    }
}
