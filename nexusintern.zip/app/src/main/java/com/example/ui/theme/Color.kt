package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Warm Neutral Palette (Technical Portfolio Aesthetic)
val NeutralWarmBackground = Color(0xFFFBFBF9)
val NeutralWarmSurface = Color(0xFFFFFFFF)
val NeutralWarmSurfaceVariant = Color(0xFFF4F3EE)
val NeutralWarmBorder = Color(0xFFE5E2DA)
val NeutralWarmBorderLight = Color(0xFFEFECE6)

val TextPrimaryCharcoal = Color(0xFF18181B)
val TextSecondarySlate = Color(0xFF475569)
val TextTertiaryMuted = Color(0xFF64748B)

// Accents (Understated, Precise)
val AccentCharcoal = Color(0xFF1E293B)
val AccentTeal = Color(0xFF0F766E)
val AccentTealLight = Color(0xFFCCFBF1)
val AccentBlue = Color(0xFF0369A1)
val AccentBlueLight = Color(0xFFE0F2FE)
val AccentAmber = Color(0xFFB45309)
val AccentAmberLight = Color(0xFFFEF3C7)
val AccentEmerald = Color(0xFF059669)
val AccentEmeraldLight = Color(0xFFD1FAE5)
val AccentRose = Color(0xFFBE123C)
val AccentRoseLight = Color(0xFFFFE4E6)

// Dark Theme Variants
val DarkBackground = Color(0xFF121417)
val DarkSurface = Color(0xFF191C20)
val DarkSurfaceVariant = Color(0xFF22262B)
val DarkBorder = Color(0xFF2E3339)
val DarkTextPrimary = Color(0xFFF1F3F5)
val DarkTextSecondary = Color(0xFF9CA3AF)
