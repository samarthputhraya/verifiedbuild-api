package com.example.ui.screens.student

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.InterviewQuestionEntity
import com.example.data.model.ProjectEntity

@Composable
fun AiInterviewScreen(
    project: ProjectEntity,
    questions: List<InterviewQuestionEntity>,
    isListening: Boolean,
    transcriptionText: String,
    speechError: String?,
    onStartSpeech: (initial: String) -> Unit,
    onStopSpeech: () -> Unit,
    onSaveAnswer: (questionId: String, answer: String, isVoice: Boolean) -> Unit,
    onSubmitInterview: () -> Unit,
    onBack: () -> Unit
) {
    if (questions.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color(0xFF0F766E))
        }
        return
    }

    var currentQuestionIndex by remember { mutableIntStateOf(0) }
    val currentQuestion = questions.getOrElse(currentQuestionIndex) { questions.first() }

    var answerText by remember(currentQuestion.id) {
        mutableStateOf(currentQuestion.studentAnswer)
    }

    var isVoiceRecorded by remember(currentQuestion.id) {
        mutableStateOf(currentQuestion.isVoiceTranscription)
    }

    var showSubmitConfirmation by remember { mutableStateOf(false) }
    var isSubmittingEvaluation by remember { mutableStateOf(false) }

    // When transcription updates from voice helper, reflect it
    LaunchedEffect(transcriptionText) {
        if (isListening && transcriptionText.isNotBlank()) {
            answerText = transcriptionText
            isVoiceRecorded = true
            onSaveAnswer(currentQuestion.id, answerText, true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFBFBF9))
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("ai_interview_screen")
    ) {
        // App Bar
        Surface(
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE5E2DA))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("interview_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color(0xFF18181B))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Technical Assessment Interview",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF18181B)
                    )
                    Text(
                        text = "Question ${currentQuestionIndex + 1} of ${questions.size} • ${project.title}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF64748B)
                    )
                }
            }
        }

        LinearProgressIndicator(
            progress = { (currentQuestionIndex + 1).toFloat() / questions.size },
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp),
            color = Color(0xFF0F766E),
            trackColor = Color(0xFFE5E2DA)
        )

        // Body
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Question Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = Color(0xFFF4F3EE),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, Color(0xFFE5E2DA))
                        ) {
                            Text(
                                text = currentQuestion.category,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF1E293B),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Surface(
                            color = when (currentQuestion.difficulty.uppercase()) {
                                "ADVANCED" -> Color(0xFFFEF3C7)
                                else -> Color(0xFFE0F2FE)
                            },
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = currentQuestion.difficulty,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = when (currentQuestion.difficulty.uppercase()) {
                                    "ADVANCED" -> Color(0xFF92400E)
                                    else -> Color(0xFF0369A1)
                                },
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = currentQuestion.questionText,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF18181B),
                        lineHeight = 24.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Rationale
                    Surface(
                        color = Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = null,
                                tint = Color(0xFF0F766E),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Assessment Rationale: ${currentQuestion.rationale}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF475569)
                            )
                        }
                    }
                }
            }

            // Student Answer Input Area
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Your Technical Response",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF18181B)
                        )

                        // Speech-to-text mic action button
                        Button(
                            onClick = {
                                if (isListening) {
                                    onStopSpeech()
                                } else {
                                    onStartSpeech(answerText)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isListening) Color(0xFFBE123C) else Color(0xFFF4F3EE),
                                contentColor = if (isListening) Color.White else Color(0xFF1E293B)
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.testTag("voice_input_toggle_button")
                        ) {
                            Icon(
                                imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                                contentDescription = "Voice Input",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isListening) "Stop Recording" else "Voice Dictation")
                        }
                    }

                    // Voice Recording Indicator
                    AnimatedVisibility(visible = isListening) {
                        Surface(
                            color = Color(0xFFFFE4E6),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.GraphicEq, contentDescription = null, tint = Color(0xFFBE123C))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Listening... Speak clearly. You can edit transcription below.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFFBE123C)
                                )
                            }
                        }
                    }

                    if (speechError != null) {
                        Surface(
                            color = Color(0xFFFEF2F2),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = speechError,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFDC2626),
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = answerText,
                        onValueChange = {
                            answerText = it
                            onSaveAnswer(currentQuestion.id, it, isVoiceRecorded)
                        },
                        label = { Text("Detailed Explanation & Implementation Rationale") },
                        placeholder = { Text("Explain your architecture, data structures, trade-offs, and edge cases...") },
                        minLines = 6,
                        maxLines = 12,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("interview_answer_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF0F766E), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Answers are auto-saved immediately",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF64748B)
                            )
                        }

                        Text(
                            text = "${answerText.trim().split(Regex("""\s+""")).filter { it.isNotBlank() }.size} words",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }

        // Bottom Action Bar
        Surface(
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE5E2DA))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (currentQuestionIndex > 0) {
                    OutlinedButton(
                        onClick = { currentQuestionIndex-- },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("interview_prev_button")
                    ) {
                        Text("Previous")
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                if (currentQuestionIndex < questions.size - 1) {
                    Button(
                        onClick = { currentQuestionIndex++ },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("interview_next_button")
                    ) {
                        Text("Next Question")
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                } else {
                    // Final Submit
                    Button(
                        onClick = { showSubmitConfirmation = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("submit_interview_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Submit for Evaluation")
                    }
                }
            }
        }
    }

    if (showSubmitConfirmation) {
        AlertDialog(
            onDismissRequest = { if (!isSubmittingEvaluation) showSubmitConfirmation = false },
            containerColor = Color.White,
            title = {
                Text(
                    text = "Submit Technical Assessment?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF18181B)
                )
            },
            text = {
                Column {
                    Text(
                        text = "Once submitted, your answers will be audited by the AI assessment agent across 8 technical dimensions (Architecture, Algorithms, Problem Solving, Concurrency, etc.).",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF475569)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Your submission will be placed under Administrator Review until released.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF0F766E),
                        fontWeight = FontWeight.Medium
                    )

                    if (isSubmittingEvaluation) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color(0xFF0F766E), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Evaluating answers against technical rubric...", style = MaterialTheme.typography.bodySmall, color = Color(0xFF1E293B))
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isSubmittingEvaluation = true
                        onSubmitInterview()
                    },
                    enabled = !isSubmittingEvaluation,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("confirm_submit_interview_button")
                ) {
                    Text("Confirm & Submit")
                }
            },
            dismissButton = {
                if (!isSubmittingEvaluation) {
                    OutlinedButton(
                        onClick = { showSubmitConfirmation = false },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Review Answers")
                    }
                }
            }
        )
    }
}
