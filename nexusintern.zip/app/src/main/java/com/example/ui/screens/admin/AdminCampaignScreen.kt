package com.example.ui.screens.admin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CampaignMessageEntity
import com.example.data.model.StudentEntity

@Composable
fun AdminCampaignScreen(
    students: List<StudentEntity>,
    campaignHistory: List<CampaignMessageEntity>,
    onSendCampaign: (subject: String, body: String, filter: String, count: Int, channel: String, template: String) -> Unit,
    onBack: () -> Unit
) {
    var selectedTemplate by remember { mutableStateOf("Shortlist Notification") }
    var filterSkill by remember { mutableStateOf("ALL") }
    var minCgpa by remember { mutableStateOf(8.5) }
    var channel by remember { mutableStateOf("EMAIL_AND_INAPP") }

    var subject by remember {
        mutableStateOf("NexusIntern: You have been shortlisted for Cloud Systems Internships")
    }
    var bodyContent by remember {
        mutableStateOf("Congratulations! Following review of your project assessment and technical radar score breakdown, your portfolio has been shortlisted for premier infrastructure opportunities.")
    }

    var showConfirmDialog by remember { mutableStateOf(false) }
    var isSending by remember { mutableStateOf(false) }
    var successToast by remember { mutableStateOf<String?>(null) }

    // Filter recipients preview
    val matchedStudents = students.filter { s ->
        val skillOk = filterSkill == "ALL" || s.technicalSkills.contains(filterSkill, ignoreCase = true)
        val cgpaOk = s.cgpa >= minCgpa
        skillOk && cgpaOk
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFBFBF9))
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("admin_campaign_screen")
    ) {
        // App Bar
        Surface(
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE5E2DA))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("campaign_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color(0xFF18181B))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Admin Email & Campaign Center",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF18181B)
                    )
                    Text(
                        text = "Targeted notifications with verified delivery tracking",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF64748B)
                    )
                }
            }
        }

        // Body
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Success Message
            if (successToast != null) {
                Surface(
                    color = Color(0xFFD1FAE5),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF065F46))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = successToast ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF065F46),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Template Selector Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Select Campaign Template",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF18181B)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val templates = listOf(
                            "Shortlist Notification" to "NexusIntern: You have been shortlisted for Cloud Systems Internships",
                            "Assessment Released" to "NexusIntern: Your Project Assessment Radar Feedback has been Released",
                            "Profile Reminder" to "Action Required: Complete your technical portfolio and submit project"
                        )
                        templates.forEach { (name, defSubj) ->
                            val isSel = selectedTemplate == name
                            Surface(
                                color = if (isSel) Color(0xFF1E293B) else Color(0xFFF4F3EE),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.clickable {
                                    selectedTemplate = name
                                    subject = defSubj
                                    bodyContent = when (name) {
                                        "Shortlist Notification" -> "Congratulations! Your assessed project evaluation has been forwarded to partnered recruiters for internship selection."
                                        "Assessment Released" -> "The platform administrator has completed review of your submitted repository assessment. Log in to explore your spider-web radar score."
                                        else -> "Please verify your GitHub profile and add your hackathon certificates to unlock candidate matching."
                                    }
                                }
                            ) {
                                Text(
                                    text = name,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSel) Color.White else Color(0xFF334155),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Recipient Group Filtering & Live Preview Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.FilterList, contentDescription = null, tint = Color(0xFF0F766E))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Recipient Group Filter (${matchedStudents.size} matched)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF18181B)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Filter by Primary Skill Stack:", style = MaterialTheme.typography.labelSmall, color = Color(0xFF64748B))
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("ALL", "Kotlin", "Go", "Python").forEach { s ->
                            val sel = filterSkill == s
                            Surface(
                                color = if (sel) Color(0xFF0F766E) else Color(0xFFF4F3EE),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.clickable { filterSkill = s }
                            ) {
                                Text(
                                    text = s,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (sel) Color.White else Color(0xFF1E293B),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Recipient Preview Chips
                    Text("Target Recipient Preview:", style = MaterialTheme.typography.labelSmall, color = Color(0xFF64748B))
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        matchedStudents.take(4).forEach { student ->
                            Surface(
                                color = Color(0xFFE0F2FE),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(
                                    text = "${student.fullName} (CGPA ${student.cgpa})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF0369A1),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Message Composer Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Message Composer",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF18181B)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = subject,
                        onValueChange = { subject = it },
                        label = { Text("Subject Line") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("campaign_subject_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = bodyContent,
                        onValueChange = { bodyContent = it },
                        label = { Text("Message Body (Rich In-App & Email)") },
                        minLines = 4,
                        maxLines = 8,
                        modifier = Modifier.fillMaxWidth().testTag("campaign_body_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { showConfirmDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("send_campaign_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Review & Send Campaign (${matchedStudents.size} Recipients)")
                    }
                }
            }

            // Past Dispatches / Audit Log
            if (campaignHistory.isNotEmpty()) {
                Text(
                    text = "Confirmed Delivery Audit Log (${campaignHistory.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF18181B)
                )

                campaignHistory.forEach { camp ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = camp.subject,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF18181B)
                                )
                                Surface(
                                    color = Color(0xFFD1FAE5),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = camp.deliveryOutcome,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF065F46),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Recipients: ${camp.recipientCount} • Filter: ${camp.recipientFilter}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showConfirmDialog) {
        AlertDialog(
            onDismissRequest = { if (!isSending) showConfirmDialog = false },
            containerColor = Color.White,
            title = {
                Text(
                    text = "Confirm Campaign Dispatch?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF18181B)
                )
            },
            text = {
                Column {
                    Text(
                        text = "This message will be dispatched via real email transport and platform notification pipes to ${matchedStudents.size} verified student accounts.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF475569)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Subject: $subject",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF18181B)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isSending = true
                        onSendCampaign(
                            subject,
                            bodyContent,
                            "Skills: $filterSkill, Min CGPA: $minCgpa",
                            matchedStudents.size,
                            channel,
                            selectedTemplate
                        )
                        isSending = false
                        showConfirmDialog = false
                        successToast = "Campaign successfully dispatched! Delivery confirmed across ${matchedStudents.size} student inboxes."
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("confirm_dispatch_campaign_btn")
                ) {
                    Text("Confirm & Dispatch")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showConfirmDialog = false },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}
