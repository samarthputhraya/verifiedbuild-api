package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColorScheme = lightColorScheme(
    primary = AccentCharcoal,
    onPrimary = Color.White,
    primaryContainer = NeutralWarmSurfaceVariant,
    onPrimaryContainer = TextPrimaryCharcoal,
    secondary = AccentTeal,
    onSecondary = Color.White,
    secondaryContainer = AccentTealLight,
    onSecondaryContainer = AccentTeal,
    tertiary = AccentBlue,
    onTertiary = Color.White,
    tertiaryContainer = AccentBlueLight,
    onTertiaryContainer = AccentBlue,
    background = NeutralWarmBackground,
    onBackground = TextPrimaryCharcoal,
    surface = NeutralWarmSurface,
    onSurface = TextPrimaryCharcoal,
    surfaceVariant = NeutralWarmSurfaceVariant,
    onSurfaceVariant = TextSecondarySlate,
    outline = NeutralWarmBorder,
    outlineVariant = NeutralWarmBorderLight,
    error = AccentRose,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFE2E8F0),
    onPrimary = Color(0xFF0F172A),
    primaryContainer = DarkSurfaceVariant,
    onPrimaryContainer = DarkTextPrimary,
    secondary = Color(0xFF2DD4BF),
    onSecondary = Color(0xFF042F2E),
    secondaryContainer = Color(0xFF134E4A),
    onSecondaryContainer = Color(0xFF5EEAD4),
    tertiary = Color(0xFF38BDF8),
    onTertiary = Color(0xFF082F49),
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextSecondary,
    outline = DarkBorder,
    error = Color(0xFFF87171),
    onError = Color(0xFF450A0A)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Force bespoke clean warm palette for brand consistency
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
