package com.example.ui.screens.admin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AssessmentReportEntity
import com.example.data.model.HackathonEntity
import com.example.data.model.InterviewQuestionEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.RecruiterEntity
import com.example.data.model.StudentEntity
import com.example.ui.components.InteractiveRadarChart
import com.example.ui.components.ScoreBadge
import com.example.ui.components.SkillChip
import com.example.ui.components.StatusBadge

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminCommandCenterScreen(
    students: List<StudentEntity>,
    projects: List<ProjectEntity>,
    reports: List<AssessmentReportEntity>,
    hackathons: List<HackathonEntity>,
    recruiters: List<RecruiterEntity>,
    questions: List<InterviewQuestionEntity>,
    onReleaseFeedback: (reportId: String, remarks: String) -> Unit,
    onForwardToRecruiter: (recruiterId: String, studentId: String, projectId: String, notes: String) -> Unit,
    onCreateRecruiter: (name: String, company: String, position: String, email: String, onResult: (Result<RecruiterEntity>) -> Unit) -> Unit,
    onOpenCampaigns: () -> Unit,
    onSwitchRole: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedSkillFilter by remember { mutableStateOf("ALL") }
    var minCgpaFilter by remember { mutableStateOf(0.0) }
    var statusFilter by remember { mutableStateOf("ALL") }

    var inspectingStudent by remember { mutableStateOf<StudentEntity?>(null) }
    var showShareFeedbackDialog by remember { mutableStateOf<AssessmentReportEntity?>(null) }
    var showForwardRecruiterDialog by remember { mutableStateOf<Pair<StudentEntity, ProjectEntity>?>(null) }
    var showCreateRecruiterDialog by remember { mutableStateOf(false) }

    val tabs = listOf("Candidates & Auditing", "Recruiter Accounts (${recruiters.size})", "Campaign Center")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFBFBF9))
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("admin_command_center_screen")
    ) {
        // Desktop / Header Bar
        Surface(
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE5E2DA))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = Color(0xFFE0E7FF),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "ADMIN COMMAND CENTER",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF3730A3),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    Text(
                        text = "Candidate Auditing & Placement Governance",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF18181B),
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onOpenCampaigns,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("admin_campaign_button")
                    ) {
                        Icon(Icons.Default.Campaign, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Campaigns")
                    }

                    IconButton(onClick = onSwitchRole, modifier = Modifier.testTag("admin_switch_role_button")) {
                        Icon(Icons.Default.SwitchAccount, contentDescription = "Switch Role", tint = Color(0xFF18181B))
                    }
                }
            }
        }

        // Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            contentColor = Color(0xFF18181B),
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = Color(0xFF3730A3),
                    height = 2.5.dp
                )
            }
        ) {
            tabs.forEachIndexed { idx, title ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = {
                        if (idx == 2) onOpenCampaigns() else selectedTab = idx
                    },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTab == idx) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (selectedTab == idx) Color(0xFF18181B) else Color(0xFF64748B)
                        )
                    }
                )
            }
        }

        // Main Body
        when (selectedTab) {
            0 -> {
                // Tab 0: Candidate Roster & Filters
                if (inspectingStudent != null) {
                    val targetStudent = inspectingStudent!!
                    val studentProjects = projects.filter { it.studentId == targetStudent.id }
                    val studentHackathons = hackathons.filter { it.studentId == targetStudent.id }

                    CandidateInspectionView(
                        student = targetStudent,
                        projects = studentProjects,
                        reports = reports,
                        hackathons = studentHackathons,
                        questions = questions,
                        onBack = { inspectingStudent = null },
                        onShareFeedback = { report -> showShareFeedbackDialog = report },
                        onForwardRecruiter = { proj -> showForwardRecruiterDialog = Pair(targetStudent, proj) }
                    )
                } else {
                    CandidateRosterView(
                        students = students,
                        projects = projects,
                        reports = reports,
                        searchQuery = searchQuery,
                        onSearchChange = { searchQuery = it },
                        selectedSkillFilter = selectedSkillFilter,
                        onSkillFilterChange = { selectedSkillFilter = it },
                        minCgpaFilter = minCgpaFilter,
                        onCgpaFilterChange = { minCgpaFilter = it },
                        onInspectStudent = { inspectingStudent = it }
                    )
                }
            }

            1 -> {
                // Tab 1: Recruiter Management
                RecruiterManagementView(
                    recruiters = recruiters,
                    onCreateRecruiterClick = { showCreateRecruiterDialog = true }
                )
            }
        }
    }

    // Share Feedback Dialog
    if (showShareFeedbackDialog != null) {
        val rep = showShareFeedbackDialog!!
        var adminRemarksInput by remember { mutableStateOf("Technical evaluation approved. Candidate demonstrates high architectural clarity.") }

        AlertDialog(
            onDismissRequest = { showShareFeedbackDialog = null },
            containerColor = Color.White,
            title = {
                Text(
                    text = "Release Assessment Feedback to Student",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF18181B)
                )
            },
            text = {
                Column {
                    Text(
                        text = "Releasing this assessment will make the complete 8-dimension spider-web radar chart and recommendations visible in the student's dashboard.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF475569)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = adminRemarksInput,
                        onValueChange = { adminRemarksInput = it },
                        label = { Text("Administrator Review Remarks") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth().testTag("admin_remarks_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onReleaseFeedback(rep.id, adminRemarksInput)
                        showShareFeedbackDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("confirm_release_feedback_button")
                ) {
                    Text("Release to Student")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showShareFeedbackDialog = null },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // Forward to Recruiter Dialog
    if (showForwardRecruiterDialog != null) {
        val (student, proj) = showForwardRecruiterDialog!!
        var selectedRecruiterId by remember { mutableStateOf(recruiters.firstOrNull()?.id ?: "") }
        var forwardNotes by remember { mutableStateOf("Candidate demonstrates strong distributed systems and Kotlin performance architecture.") }

        AlertDialog(
            onDismissRequest = { showForwardRecruiterDialog = null },
            containerColor = Color.White,
            title = {
                Text(
                    text = "Forward Candidate to Recruiter",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF18181B)
                )
            },
            text = {
                Column {
                    Text(
                        text = "Forward ${student.fullName} for '${proj.title}'. The recruiter will receive authorized portfolio and approved reports only. Raw interview transcripts remain private.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF475569)
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Text("Select Recruiter Target:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    recruiters.forEach { r ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedRecruiterId = r.id }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = if (selectedRecruiterId == r.id) Color(0xFF0F766E) else Color(0xFFE2E8F0),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.size(16.dp)
                            ) {}
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "${r.fullName} • ${r.companyName} (${r.position})",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF1E293B)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = forwardNotes,
                        onValueChange = { forwardNotes = it },
                        label = { Text("Admin Recommendation Note") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth().testTag("forward_notes_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (selectedRecruiterId.isNotBlank()) {
                            onForwardToRecruiter(selectedRecruiterId, student.id, proj.id, forwardNotes)
                            showForwardRecruiterDialog = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("confirm_forward_recruiter_button")
                ) {
                    Text("Forward Profile")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showForwardRecruiterDialog = null },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // Create Recruiter Account Dialog
    if (showCreateRecruiterDialog) {
        var recName by remember { mutableStateOf("") }
        var recCompany by remember { mutableStateOf("") }
        var recPosition by remember { mutableStateOf("") }
        var recEmail by remember { mutableStateOf("") }
        var errorMessage by remember { mutableStateOf<String?>(null) }
        var isCreating by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!isCreating) showCreateRecruiterDialog = false },
            containerColor = Color.White,
            title = {
                Text(
                    text = "Provision Recruiter Account",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF18181B)
                )
            },
            text = {
                Column {
                    Text(
                        text = "Only Administrators can provision recruiter accounts. A secure temporary credential will be generated.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF64748B),
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    OutlinedTextField(
                        value = recName,
                        onValueChange = { recName = it },
                        label = { Text("Recruiter Full Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("recruiter_name_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = recCompany,
                        onValueChange = { recCompany = it },
                        label = { Text("Company Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("recruiter_company_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = recPosition,
                        onValueChange = { recPosition = it },
                        label = { Text("Position / Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("recruiter_position_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = recEmail,
                        onValueChange = { recEmail = it },
                        label = { Text("Corporate Email") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("recruiter_email_input")
                    )

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorMessage ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFDC2626)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (recName.isBlank() || recCompany.isBlank() || recEmail.isBlank()) {
                            errorMessage = "All fields are required."
                            return@Button
                        }
                        isCreating = true
                        onCreateRecruiter(recName, recCompany, recPosition, recEmail) { res ->
                            isCreating = false
                            res.onSuccess {
                                showCreateRecruiterDialog = false
                            }.onFailure {
                                errorMessage = it.message ?: "Failed to provision account."
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("confirm_create_recruiter_button")
                ) {
                    Text("Provision Account")
                }
            },
            dismissButton = {
                if (!isCreating) {
                    OutlinedButton(
                        onClick = { showCreateRecruiterDialog = false },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Cancel")
                    }
                }
            }
        )
    }
}

@Composable
private fun CandidateRosterView(
    students: List<StudentEntity>,
    projects: List<ProjectEntity>,
    reports: List<AssessmentReportEntity>,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    selectedSkillFilter: String,
    onSkillFilterChange: (String) -> Unit,
    minCgpaFilter: Double,
    onCgpaFilterChange: (Double) -> Unit,
    onInspectStudent: (StudentEntity) -> Unit
) {
    val filteredStudents = students.filter { s ->
        val matchesSearch = s.fullName.contains(searchQuery, ignoreCase = true) ||
                s.college.contains(searchQuery, ignoreCase = true) ||
                s.technicalSkills.contains(searchQuery, ignoreCase = true)

        val matchesSkill = selectedSkillFilter == "ALL" || s.technicalSkills.contains(selectedSkillFilter, ignoreCase = true)
        val matchesCgpa = s.cgpa >= minCgpaFilter
        matchesSearch && matchesSkill && matchesCgpa
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Search & Filters Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchChange,
                        label = { Text("Search by candidate name, university, or tech stack...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF64748B)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("admin_candidate_search_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("ALL", "Kotlin", "Go", "Python", "Rust").forEach { skill ->
                            Surface(
                                color = if (selectedSkillFilter == skill) Color(0xFF1E293B) else Color(0xFFF4F3EE),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.clickable { onSkillFilterChange(skill) }
                            ) {
                                Text(
                                    text = skill,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Medium,
                                    color = if (selectedSkillFilter == skill) Color.White else Color(0xFF334155),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Candidates List
        items(filteredStudents, key = { it.id }) { student ->
            val studentProjects = projects.filter { it.studentId == student.id }
            val highestScore = reports.filter { it.studentId == student.id }.maxOfOrNull { it.overallScore }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_candidate_row_${student.id}")
                    .clickable { onInspectStudent(student) },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = student.fullName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF18181B)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = Color(0xFFF4F3EE),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "CGPA ${student.cgpa}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F766E),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = "${student.college} • ${student.branch}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            student.technicalSkills.split(",").take(4).forEach {
                                SkillChip(skill = it)
                            }
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        if (highestScore != null) {
                            ScoreBadge(score = highestScore)
                        } else {
                            Surface(
                                color = Color(0xFFF1F5F9),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "${studentProjects.size} Projects",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF475569),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Inspect Audit",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF3730A3)
                            )
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                tint = Color(0xFF3730A3),
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CandidateInspectionView(
    student: StudentEntity,
    projects: List<ProjectEntity>,
    reports: List<AssessmentReportEntity>,
    hackathons: List<HackathonEntity>,
    questions: List<InterviewQuestionEntity>,
    onBack: () -> Unit,
    onShareFeedback: (AssessmentReportEntity) -> Unit,
    onForwardRecruiter: (ProjectEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Back Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = "Full Candidate Audit Dossier",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF18181B)
                    )
                    Text(
                        text = "${student.fullName} • ${student.email}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF64748B)
                    )
                }
            }
        }

        // Student Overview Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(text = "Academic & Technical Profile", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "University: ${student.college} • ${student.branch}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF334155))
                    Text(text = "CGPA: ${student.cgpa} • Year: ${student.academicYear}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF475569))
                    Text(text = "GitHub: ${student.githubProfileUrl}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF0284C7))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Stack: ${student.technicalSkills}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF475569))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "Resume Summary: ${student.resumeSummary}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF334155))
                }
            }
        }

        // Submitted Projects & Assessment Reports
        item {
            Text(
                text = "Submitted Projects & Rubric Evaluations (${projects.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF18181B)
            )
        }

        items(projects) { proj ->
            val rep = reports.find { it.projectId == proj.id }
            val projQuestions = questions.filter { it.projectId == proj.id }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = proj.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(text = proj.githubRepoUrl, style = MaterialTheme.typography.bodySmall, color = Color(0xFF0284C7))
                        }
                        StatusBadge(status = proj.status)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (rep != null) {
                        // Assessment details
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "AI Assessment Score: ${rep.overallScore}/100",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F766E)
                            )

                            if (rep.feedbackSharedWithStudent) {
                                Surface(color = Color(0xFFD1FAE5), shape = RoundedCornerShape(6.dp)) {
                                    Text(
                                        text = "Feedback Released",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF065F46),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            } else {
                                Button(
                                    onClick = { onShareFeedback(rep) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.testTag("admin_share_feedback_btn_${rep.id}")
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Share Feedback with Student")
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Interactive Radar Chart embedded directly in Admin inspection view
                        InteractiveRadarChart(report = rep)

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Admin Integrity Observations:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = rep.integrityObservations,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF475569)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Forward to Recruiter Action
                        Button(
                            onClick = { onForwardRecruiter(proj) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("admin_forward_recruiter_btn_${proj.id}")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Forward Profile to Recruiter")
                        }
                    } else {
                        Text(
                            text = "No assessment completed yet for this project. Status: ${proj.status}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B)
                        )
                    }

                    // Raw Interview QA Inspection (Admin only!)
                    if (projQuestions.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Candidate Raw Interview Q&A Responses (${projQuestions.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF18181B)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        projQuestions.forEachIndexed { idx, q ->
                            Surface(
                                color = Color(0xFFF8FAFC),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = "Q${idx + 1} (${q.category}): ${q.questionText}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF1E293B)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Answer: ${if (q.studentAnswer.isNotBlank()) q.studentAnswer else "[No response recorded]"}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF475569)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecruiterManagementView(
    recruiters: List<RecruiterEntity>,
    onCreateRecruiterClick: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Provisioned Recruiter Portals",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF18181B)
                    )
                    Text(
                        text = "Recruiter accounts are strictly provisioned by Admin credentials.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF64748B)
                    )
                }

                Button(
                    onClick = onCreateRecruiterClick,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("admin_provision_recruiter_btn")
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Provision Recruiter")
                }
            }
        }

        items(recruiters) { rec ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE5E2DA)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = rec.fullName,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF18181B)
                            )
                            Text(
                                text = "${rec.companyName} • ${rec.position}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF0F766E),
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Surface(
                            color = if (rec.permanentPasswordEstablished) Color(0xFFD1FAE5) else Color(0xFFFEF3C7),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = if (rec.permanentPasswordEstablished) "Active" else "Temporary Credential",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (rec.permanentPasswordEstablished) Color(0xFF065F46) else Color(0xFF92400E),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Email: ${rec.email}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF475569)
                    )

                    if (!rec.permanentPasswordEstablished) {
                        Text(
                            text = "Temporary Credential: ${rec.temporaryPassword}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFB45309),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}
