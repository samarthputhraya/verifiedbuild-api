package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun StatusBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, dotColor, label) = when (status.uppercase()) {
        "SUBMITTED" -> Quad(Color(0xFFF1F5F9), Color(0xFF475569), Color(0xFF64748B), "Submitted")
        "INTERVIEW_PENDING" -> Quad(Color(0xFFFEF3C7), Color(0xFF92400E), Color(0xFFD97706), "Interview Pending")
        "EVALUATION_COMPLETED" -> Quad(Color(0xFFD1FAE5), Color(0xFF065F46), Color(0xFF059669), "Evaluation Released")
        "UNDER_ADMIN_REVIEW" -> Quad(Color(0xFFE0E7FF), Color(0xFF3730A3), Color(0xFF6366F1), "Under Admin Review")
        "SHARED_WITH_RECRUITER" -> Quad(Color(0xFFCCFBF1), Color(0xFF115E59), Color(0xFF0D9488), "Shared with Recruiter")
        "SHORTLISTED" -> Quad(Color(0xFFD1FAE5), Color(0xFF065F46), Color(0xFF059669), "Shortlisted")
        "ACCEPTED" -> Quad(Color(0xFFD1FAE5), Color(0xFF065F46), Color(0xFF059669), "Mutual Connection")
        "PENDING" -> Quad(Color(0xFFFEF3C7), Color(0xFF92400E), Color(0xFFD97706), "Request Pending")
        else -> Quad(Color(0xFFF3F4F6), Color(0xFF374151), Color(0xFF6B7280), status)
    }

    Surface(
        modifier = modifier,
        color = bgColor,
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Medium,
                color = textColor
            )
        }
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@Composable
fun SkillChip(
    skill: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = Color(0xFFF4F3EE),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E2DA))
    ) {
        Text(
            text = skill.trim(),
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF1E293B),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun ScoreBadge(
    score: Int,
    label: String = "Score",
    modifier: Modifier = Modifier
) {
    val (bg, fg) = when {
        score >= 85 -> Pair(Color(0xFFD1FAE5), Color(0xFF065F46))
        score >= 70 -> Pair(Color(0xFFFEF3C7), Color(0xFF92400E))
        else -> Pair(Color(0xFFF1F5F9), Color(0xFF334155))
    }

    Surface(
        modifier = modifier,
        color = bg,
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$score",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = fg
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "/ 100",
                style = MaterialTheme.typography.labelSmall,
                color = fg.copy(alpha = 0.8f)
            )
        }
    }
}
