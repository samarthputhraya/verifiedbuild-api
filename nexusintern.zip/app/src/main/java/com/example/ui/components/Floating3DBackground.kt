package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.cos
import kotlin.math.sin

/**
 * Minimal 3D geometric objects floating subtly in the background of the opening screen.
 * Restrained depth, soft lighting, and smooth micro-animations on warm off-white canvas.
 */
@Composable
fun Floating3DBackground(
    modifier: Modifier = Modifier,
    baseColor: Color = Color(0xFF1E293B)
) {
    val infiniteTransition = rememberInfiniteTransition(label = "floating_3d")

    val phase1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 24000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase1"
    )

    val phase2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 32000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase2"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Subtle ambient dot grid
        val step = 48f
        val dotColor = baseColor.copy(alpha = 0.035f)
        var x = step / 2
        while (x < w) {
            var y = step / 2
            while (y < h) {
                drawCircle(color = dotColor, radius = 1.2f, center = Offset(x, y))
                y += step
            }
            x += step
        }

        // Object 1: Isometric Floating Cube (Top Right)
        val rad1 = Math.toRadians(phase1.toDouble())
        val bob1 = sin(rad1).toFloat() * 14f
        val center1 = Offset(w * 0.82f, h * 0.16f + bob1)
        drawIsometricCube(
            center = center1,
            size = 38f,
            rotationAngle = phase1 * 0.5f,
            color = baseColor
        )

        // Object 2: Floating Octahedron / Diamond Polyhedron (Bottom Left)
        val rad2 = Math.toRadians(phase2.toDouble())
        val bob2 = cos(rad2).toFloat() * 18f
        val center2 = Offset(w * 0.15f, h * 0.72f + bob2)
        drawOctahedron(
            center = center2,
            radius = 42f,
            angle = phase2,
            color = baseColor
        )

        // Object 3: Subtle Interconnected Geometric Node (Center Right)
        val bob3 = sin(rad2 * 1.2).toFloat() * 10f
        val center3 = Offset(w * 0.88f, h * 0.58f + bob3)
        drawWireframePrism(
            center = center3,
            radius = 26f,
            color = baseColor
        )

        // Object 4: Floating Minimal Ring Polygon (Top Left)
        val bob4 = cos(rad1 * 0.8).toFloat() * 8f
        val center4 = Offset(w * 0.12f, h * 0.22f + bob4)
        drawFloatingPolygon(
            center = center4,
            radius = 22f,
            sides = 6,
            angle = phase1 * 0.3f,
            color = baseColor
        )
    }
}

private fun DrawScope.drawIsometricCube(
    center: Offset,
    size: Float,
    rotationAngle: Float,
    color: Color
) {
    val h = size * 0.866f // sqrt(3)/2
    val halfH = h / 2f
    val halfS = size / 2f

    // Top Face (Lighter shade)
    val topPath = Path().apply {
        moveTo(center.x, center.y - size)
        lineTo(center.x + h, center.y - halfS)
        lineTo(center.x, center.y)
        lineTo(center.x - h, center.y - halfS)
        close()
    }
    drawPath(topPath, color.copy(alpha = 0.07f), style = Fill)
    drawPath(topPath, color.copy(alpha = 0.15f), style = Stroke(width = 1.2f))

    // Left Face (Mid tone)
    val leftPath = Path().apply {
        moveTo(center.x - h, center.y - halfS)
        lineTo(center.x, center.y)
        lineTo(center.x, center.y + size)
        lineTo(center.x - h, center.y + halfS)
        close()
    }
    drawPath(leftPath, color.copy(alpha = 0.05f), style = Fill)
    drawPath(leftPath, color.copy(alpha = 0.12f), style = Stroke(width = 1.2f))

    // Right Face (Subtle shadow)
    val rightPath = Path().apply {
        moveTo(center.x, center.y)
        lineTo(center.x + h, center.y - halfS)
        lineTo(center.x + h, center.y + halfS)
        lineTo(center.x, center.y + size)
        close()
    }
    drawPath(rightPath, color.copy(alpha = 0.03f), style = Fill)
    drawPath(rightPath, color.copy(alpha = 0.12f), style = Stroke(width = 1.2f))
}

private fun DrawScope.drawOctahedron(
    center: Offset,
    radius: Float,
    angle: Float,
    color: Color
) {
    val top = Offset(center.x, center.y - radius * 1.2f)
    val bottom = Offset(center.x, center.y + radius * 1.2f)
    val left = Offset(center.x - radius, center.y)
    val right = Offset(center.x + radius, center.y)
    val front = Offset(center.x, center.y + radius * 0.35f)

    // Upper Front-Left triangle
    val p1 = Path().apply {
        moveTo(top.x, top.y)
        lineTo(left.x, left.y)
        lineTo(front.x, front.y)
        close()
    }
    drawPath(p1, color.copy(alpha = 0.06f), style = Fill)
    drawPath(p1, color.copy(alpha = 0.14f), style = Stroke(width = 1.2f))

    // Upper Front-Right triangle
    val p2 = Path().apply {
        moveTo(top.x, top.y)
        lineTo(right.x, right.y)
        lineTo(front.x, front.y)
        close()
    }
    drawPath(p2, color.copy(alpha = 0.04f), style = Fill)
    drawPath(p2, color.copy(alpha = 0.14f), style = Stroke(width = 1.2f))

    // Lower Front-Left triangle
    val p3 = Path().apply {
        moveTo(bottom.x, bottom.y)
        lineTo(left.x, left.y)
        lineTo(front.x, front.y)
        close()
    }
    drawPath(p3, color.copy(alpha = 0.05f), style = Fill)
    drawPath(p3, color.copy(alpha = 0.12f), style = Stroke(width = 1.2f))

    // Lower Front-Right triangle
    val p4 = Path().apply {
        moveTo(bottom.x, bottom.y)
        lineTo(right.x, right.y)
        lineTo(front.x, front.y)
        close()
    }
    drawPath(p4, color.copy(alpha = 0.03f), style = Fill)
    drawPath(p4, color.copy(alpha = 0.12f), style = Stroke(width = 1.2f))
}

private fun DrawScope.drawWireframePrism(
    center: Offset,
    radius: Float,
    color: Color
) {
    val offset1 = Offset(center.x - radius, center.y - radius * 0.6f)
    val offset2 = Offset(center.x + radius, center.y - radius * 0.6f)
    val offset3 = Offset(center.x, center.y + radius)

    val path = Path().apply {
        moveTo(offset1.x, offset1.y)
        lineTo(offset2.x, offset2.y)
        lineTo(offset3.x, offset3.y)
        close()
    }
    drawPath(path, color.copy(alpha = 0.04f), style = Fill)
    drawPath(path, color.copy(alpha = 0.15f), style = Stroke(width = 1.2f))

    // Center focal point
    drawCircle(color = color.copy(alpha = 0.2f), radius = 2.5f, center = center)
}

private fun DrawScope.drawFloatingPolygon(
    center: Offset,
    radius: Float,
    sides: Int,
    angle: Float,
    color: Color
) {
    val path = Path()
    val angleStep = (2.0 * Math.PI) / sides
    val startAngle = Math.toRadians(angle.toDouble())

    for (i in 0 until sides) {
        val a = startAngle + i * angleStep
        val px = (center.x + radius * cos(a)).toFloat()
        val py = (center.y + radius * sin(a)).toFloat()
        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
    }
    path.close()

    drawPath(path, color.copy(alpha = 0.03f), style = Fill)
    drawPath(path, color.copy(alpha = 0.12f), style = Stroke(width = 1f))
}
